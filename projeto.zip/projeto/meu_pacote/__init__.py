# __init__.py
# Este arquivo torna a pasta 'meu_pacote' um pacote Python.
