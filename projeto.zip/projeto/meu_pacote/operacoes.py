# operacoes.py

def multiplica(a, b):
    """Retorna o produto de dois números."""
    return a * b
