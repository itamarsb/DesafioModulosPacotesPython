# mensagens.py

def boas_vindas(nome):
    """Retorna uma saudação personalizada."""
    return f"Bem-vindo, {nome}! Vamos aprender Python!"
